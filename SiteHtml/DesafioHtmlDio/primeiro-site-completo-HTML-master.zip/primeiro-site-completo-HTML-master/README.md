# Site para desafio da Digital Innovation One (Criando seu Primeiro Site Completo com HTML):computer:

Olá pessoal! Neste projeto, me baseei em algumas tags aprendidas no Bootcamp da DIO.me em parceria com a NTT.

Foram utilizados os seguintes conhecimentos:
 - Formulários;
 - Estruturação e formatação de texto;
 - Mídias;
 - Tabelas.
 
Abaixo temos algumas imagens do que foi pedido nesse projeto.

![image](https://user-images.githubusercontent.com/112975428/199615764-709a09d8-6366-42dc-84ce-3008b9c8c683.png)

![image](https://user-images.githubusercontent.com/112975428/199615826-4ea58091-57cd-4ffe-8781-fedc338272ac.png)

Agradeço por chegar até aqui. Espero cada vez melhorar mais minhas habilidades com programação:heart:
